﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigitalUhr
{
    public class Zaehler
    {
        private int max, zahl, stunden, minuten, sekunden;
        public Zaehler(int max, int startingPoint)
        { 
            this.max = max;
            zahl = startingPoint;
        }

        public void startUhr()
        {
            if (max > zahl)
            {
                zahl++;
            }
            else if (zahl == 60)
            {
                zahl = 0;
            }
            else
            {
                zahl = 0;
            }
        }

        public int gibZahl()
        { 
            return zahl;
        }

        public void setzeZahl(int zahl)
        { 
            this.zahl = zahl;
        }
    }
}
