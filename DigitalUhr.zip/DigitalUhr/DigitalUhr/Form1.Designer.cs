﻿namespace DigitalUhr
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            uhrAnzeige = new Label();
            groupBox2 = new GroupBox();
            button10 = new Button();
            weiterStoppuhr = new Button();
            stoppUhrAnzeige = new Label();
            button2 = new Button();
            button1 = new Button();
            groupBox3 = new GroupBox();
            weckerAnzeige = new Label();
            button4 = new Button();
            button3 = new Button();
            groupBox4 = new GroupBox();
            weckerStatus = new TextBox();
            label4 = new Label();
            button9 = new Button();
            button8 = new Button();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            sekundenTextBox = new TextBox();
            minutenTextBox = new TextBox();
            stundenTextBox = new TextBox();
            button7 = new Button();
            button5 = new Button();
            checkBox1 = new CheckBox();
            button11 = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(uhrAnzeige);
            groupBox1.Location = new Point(12, 26);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(776, 172);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Uhr";
            // 
            // uhrAnzeige
            // 
            uhrAnzeige.AutoSize = true;
            uhrAnzeige.BackColor = Color.Transparent;
            uhrAnzeige.Font = new Font("Segoe UI", 72F, FontStyle.Regular, GraphicsUnit.Point, 0);
            uhrAnzeige.Location = new Point(151, 0);
            uhrAnzeige.Name = "uhrAnzeige";
            uhrAnzeige.Size = new Size(509, 159);
            uhrAnzeige.TabIndex = 0;
            uhrAnzeige.Text = "00:00:00";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button11);
            groupBox2.Controls.Add(button10);
            groupBox2.Controls.Add(weiterStoppuhr);
            groupBox2.Controls.Add(stoppUhrAnzeige);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(button1);
            groupBox2.Location = new Point(12, 215);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(457, 125);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Stoppuhr";
            // 
            // button10
            // 
            button10.Location = new Point(251, 69);
            button10.Name = "button10";
            button10.Size = new Size(94, 34);
            button10.TabIndex = 3;
            button10.Text = "Reset";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // weiterStoppuhr
            // 
            weiterStoppuhr.Location = new Point(151, 69);
            weiterStoppuhr.Name = "weiterStoppuhr";
            weiterStoppuhr.Size = new Size(94, 34);
            weiterStoppuhr.TabIndex = 2;
            weiterStoppuhr.Text = "Weiter";
            weiterStoppuhr.UseVisualStyleBackColor = true;
            weiterStoppuhr.Click += weiterStoppuhr_Click;
            // 
            // stoppUhrAnzeige
            // 
            stoppUhrAnzeige.AutoSize = true;
            stoppUhrAnzeige.BackColor = Color.Transparent;
            stoppUhrAnzeige.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            stoppUhrAnzeige.Location = new Point(17, 43);
            stoppUhrAnzeige.Name = "stoppUhrAnzeige";
            stoppUhrAnzeige.Size = new Size(128, 41);
            stoppUhrAnzeige.TabIndex = 1;
            stoppUhrAnzeige.Text = "00:00:00";
            // 
            // button2
            // 
            button2.Location = new Point(251, 29);
            button2.Name = "button2";
            button2.Size = new Size(94, 34);
            button2.TabIndex = 1;
            button2.Text = "Stop";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_1;
            // 
            // button1
            // 
            button1.Location = new Point(151, 29);
            button1.Name = "button1";
            button1.Size = new Size(94, 34);
            button1.TabIndex = 0;
            button1.Text = "Start";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(weckerAnzeige);
            groupBox3.Controls.Add(button4);
            groupBox3.Controls.Add(button3);
            groupBox3.Location = new Point(485, 215);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(303, 125);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Wecker";
            // 
            // weckerAnzeige
            // 
            weckerAnzeige.AutoSize = true;
            weckerAnzeige.BackColor = Color.Transparent;
            weckerAnzeige.Font = new Font("Segoe UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            weckerAnzeige.Location = new Point(25, 43);
            weckerAnzeige.Name = "weckerAnzeige";
            weckerAnzeige.Size = new Size(128, 41);
            weckerAnzeige.TabIndex = 2;
            weckerAnzeige.Text = "00:00:00";
            // 
            // button4
            // 
            button4.Location = new Point(159, 69);
            button4.Name = "button4";
            button4.Size = new Size(109, 34);
            button4.TabIndex = 1;
            button4.Text = "Schlummern";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.Location = new Point(159, 29);
            button3.Name = "button3";
            button3.Size = new Size(109, 34);
            button3.TabIndex = 0;
            button3.Text = "Alarm aus";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(weckerStatus);
            groupBox4.Controls.Add(label4);
            groupBox4.Controls.Add(button9);
            groupBox4.Controls.Add(button8);
            groupBox4.Controls.Add(label3);
            groupBox4.Controls.Add(label2);
            groupBox4.Controls.Add(label1);
            groupBox4.Controls.Add(sekundenTextBox);
            groupBox4.Controls.Add(minutenTextBox);
            groupBox4.Controls.Add(stundenTextBox);
            groupBox4.Controls.Add(button7);
            groupBox4.Controls.Add(button5);
            groupBox4.Location = new Point(12, 346);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(776, 125);
            groupBox4.TabIndex = 4;
            groupBox4.TabStop = false;
            groupBox4.Text = "Einstellungen";
            groupBox4.Visible = false;
            // 
            // weckerStatus
            // 
            weckerStatus.Location = new Point(649, 58);
            weckerStatus.Name = "weckerStatus";
            weckerStatus.ReadOnly = true;
            weckerStatus.Size = new Size(101, 27);
            weckerStatus.TabIndex = 11;
            weckerStatus.Text = "Aus";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(649, 35);
            label4.Name = "label4";
            label4.Size = new Size(101, 20);
            label4.TabIndex = 10;
            label4.Text = "Wecker Status";
            // 
            // button9
            // 
            button9.Location = new Point(473, 81);
            button9.Name = "button9";
            button9.Size = new Size(144, 44);
            button9.TabIndex = 9;
            button9.Text = "Wecker ausmachen";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button8
            // 
            button8.Location = new Point(473, 26);
            button8.Name = "button8";
            button8.Size = new Size(144, 44);
            button8.TabIndex = 8;
            button8.Text = "Wecker anmachen";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(211, 35);
            label3.Name = "label3";
            label3.Size = new Size(73, 20);
            label3.TabIndex = 7;
            label3.Text = "Sekunden";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(130, 35);
            label2.Name = "label2";
            label2.Size = new Size(63, 20);
            label2.TabIndex = 6;
            label2.Text = "Minuten";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(49, 35);
            label1.Name = "label1";
            label1.Size = new Size(63, 20);
            label1.TabIndex = 5;
            label1.Text = "Stunden";
            // 
            // sekundenTextBox
            // 
            sekundenTextBox.Location = new Point(211, 69);
            sekundenTextBox.Name = "sekundenTextBox";
            sekundenTextBox.Size = new Size(60, 27);
            sekundenTextBox.TabIndex = 4;
            // 
            // minutenTextBox
            // 
            minutenTextBox.Location = new Point(130, 69);
            minutenTextBox.Name = "minutenTextBox";
            minutenTextBox.Size = new Size(60, 27);
            minutenTextBox.TabIndex = 3;
            // 
            // stundenTextBox
            // 
            stundenTextBox.Location = new Point(49, 69);
            stundenTextBox.Name = "stundenTextBox";
            stundenTextBox.Size = new Size(60, 27);
            stundenTextBox.TabIndex = 2;
            // 
            // button7
            // 
            button7.Location = new Point(330, 78);
            button7.Name = "button7";
            button7.Size = new Size(127, 44);
            button7.TabIndex = 1;
            button7.Text = "Setze Wecker";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button5
            // 
            button5.Location = new Point(330, 26);
            button5.Name = "button5";
            button5.Size = new Size(127, 44);
            button5.TabIndex = 0;
            button5.Text = "Setze Uhr";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(669, 444);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(119, 24);
            checkBox1.TabIndex = 5;
            checkBox1.Text = "Einstellungen";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // button11
            // 
            button11.Location = new Point(351, 29);
            button11.Name = "button11";
            button11.Size = new Size(94, 74);
            button11.TabIndex = 4;
            button11.Text = "Speichern";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 480);
            Controls.Add(checkBox1);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(groupBox4);
            Name = "Form1";
            Text = " Digital Uhr - Halit Yazaydin";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private Button button2;
        private Button button1;
        private Button button4;
        private Button button3;
        private Label uhrAnzeige;
        private Button button6;
        private Label stoppUhrAnzeige;
        private Label weckerAnzeige;
        private GroupBox groupBox4;
        private CheckBox checkBox1;
        private TextBox sekundenTextBox;
        private TextBox minutenTextBox;
        private TextBox stundenTextBox;
        private Button button7;
        private Button button5;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button button9;
        private Button button8;
        private TextBox weckerStatus;
        private Label label4;
        private Button weiterStoppuhr;
        private Button button10;
        private Button button11;
    }
}
