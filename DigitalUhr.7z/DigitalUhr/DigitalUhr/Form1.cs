using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Media;
using System.Numerics;
using System.Windows.Forms;

namespace DigitalUhr
{
    public partial class Form1 : Form
    {
        private Zaehler sekunden, minuten, stunden, stoppUhrStunden, stoppUhrMinuten, stoppUhrSekunden, weckerStunden, weckerMinuten, weckerSekunden;
        private bool stoppUhrAn = false;
        private bool einstellungen = false;
        private bool weckerAn = false;
        private bool alarm = false;
        private SoundPlayer player;
        public Form1()
        {
            InitializeComponent();
            sekunden = new Zaehler(59, 0);
            minuten = new Zaehler(59, 0);
            stunden = new Zaehler(23, 0);


            Task.Run(() =>
            {
                while (true)
                {
                    sekunden.startUhr();
                    Thread.Sleep(1000);

                    if (sekunden.gibZahl() == 0)
                    {
                        minuten.startUhr();
                        if (minuten.gibZahl() == 0)
                        {
                            stunden.startUhr();
                        }
                    }

                    // Update the UI safely
                    updateGUI();

                    klingeln();
                }
            });



        }

        private void updateGUI()
        {
            this.Invoke((Action)(() =>
            {
                uhrAnzeige.Text = stunden.gibZahl().ToString("D2") + ":" + minuten.gibZahl().ToString("D2") + ":" + sekunden.gibZahl().ToString("D2");
            }));
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!stoppUhrAn)
            {
                stoppUhrAn = true;
                stoppUhrAnzeige.Text = "00:00:00";

                stoppUhrSekunden = new Zaehler(59, 0);
                stoppUhrMinuten = new Zaehler(59, 0);
                stoppUhrStunden = new Zaehler(23, 0);

                Task.Run(() =>
                {
                    while (stoppUhrAn == true)
                    {
                        this.Invoke((Action)(() =>
                        {
                            stoppUhrAnzeige.Text = stoppUhrStunden.gibZahl().ToString("D2") + ":" + stoppUhrMinuten.gibZahl().ToString("D2") + ":" + stoppUhrSekunden.gibZahl().ToString("D2");
                        }));

                        stoppUhrSekunden.startUhr();
                        Thread.Sleep(1000);

                        if (stoppUhrSekunden.gibZahl() == 0)
                        {
                            stoppUhrMinuten.startUhr();
                            if (stoppUhrMinuten.gibZahl() == 0)
                            {
                                stoppUhrStunden.startUhr();
                            }
                        }

                    }
                });
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            stoppUhrAn = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            StopAlarmSound();
            alarm = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (alarm)
            {
                StopAlarmSound();
                weckerMinuten.setzeZahl(weckerMinuten.gibZahl() + 5);
                weckerAnzeige.Text = weckerStunden.gibZahl().ToString("D2") + ":" + weckerMinuten.gibZahl().ToString("D2") + ":" + weckerSekunden.gibZahl().ToString("D2");
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (!einstellungen)
            {
                einstellungen = true;
                groupBox4.Visible = true;
            }
            else
            {
                einstellungen = false;
                groupBox4.Visible = false;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                int sekunden = Convert.ToInt32(sekundenTextBox.Text);
                int minuten = Convert.ToInt32(minutenTextBox.Text);
                int stunden = Convert.ToInt32(stundenTextBox.Text);

                if (sekunden <= 59 &&
                    sekunden >= 0 &&
                    minuten <= 59 &&
                    minuten >= 0 &&
                    stunden <= 23 &&
                    stunden >= 0
                    )
                {
                    this.sekunden.setzeZahl(sekunden);
                    this.minuten.setzeZahl(minuten);
                    this.stunden.setzeZahl(stunden);
                }

                else
                {
                    MessageBox.Show("Bitte geben Sie ein g�ltige Zahl ein", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Bitte geben Sie ein g�ltige Zahl ein", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (weckerAn)
            {
                try
                {
                    int sekunden = Convert.ToInt32(sekundenTextBox.Text);
                    int minuten = Convert.ToInt32(minutenTextBox.Text);
                    int stunden = Convert.ToInt32(stundenTextBox.Text);

                    weckerSekunden = new Zaehler(59, 0);
                    weckerMinuten = new Zaehler(59, 0);
                    weckerStunden = new Zaehler(23, 0);

                    if (sekunden <= 59 &&
                        sekunden >= 0 &&
                        minuten <= 59 &&
                        minuten >= 0 &&
                        stunden <= 23 &&
                        stunden >= 0
                    )
                    {
                        this.weckerSekunden.setzeZahl(sekunden);
                        this.weckerMinuten.setzeZahl(minuten);
                        this.weckerStunden.setzeZahl(stunden);

                        this.Invoke((Action)(() =>
                        {
                            weckerAnzeige.Text = weckerStunden.gibZahl().ToString("D2") + ":" + weckerMinuten.gibZahl().ToString("D2") + ":" + weckerSekunden.gibZahl().ToString("D2");
                        }));
                    }

                    else
                    {
                        MessageBox.Show("Bitte geben Sie ein g�ltige Zahl ein", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Bitte geben Sie ein g�ltige Zahl ein", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }


            }
            else
            {
                MessageBox.Show("Bitte machen Sie erst den Wecker an.", "Wecker ist aus", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        public void klingeln()
        {
            alarm = true;
            
                if (weckerAn && weckerAnzeige.Text != "00:00:00" && weckerAnzeige.Text == uhrAnzeige.Text)
                {

                     try
                     {
                         // Path to the alarm sound (replace with your .wav file path)
                         string soundFilePath = "C:\\Users\\halit\\Desktop\\C# Projects\\DigitalUhr\\alarm.wav";

                         if (player == null)
                         {
                             player = new SoundPlayer(soundFilePath);
                         }

                         player.PlayLooping(); // Play the sound in a loop
                     }
                     catch (Exception ex)
                     {
                         Console.WriteLine($"Error playing sound: {ex.Message}");
                     }

            }
        }
        public void StopAlarmSound()
        {
            try
            {
                if (player != null)
                {
                    player.Stop(); // Stop the sound
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error stopping sound: {ex.Message}");
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            weckerAn = true;
            weckerStatus.Text = "An";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            weckerAn = false;
            weckerStatus.Text = "Aus";
            weckerAnzeige.Text = "00:00:00";
        }

        private void weiterStoppuhr_Click(object sender, EventArgs e)
        {

            if (!stoppUhrAn)
            {
                stoppUhrAn = true;

                Task.Run(() =>
                {
                    while (stoppUhrAn == true)
                    {
                        this.Invoke((Action)(() =>
                        {
                            stoppUhrAnzeige.Text = stoppUhrStunden.gibZahl().ToString("D2") + ":" + stoppUhrMinuten.gibZahl().ToString("D2") + ":" + stoppUhrSekunden.gibZahl().ToString("D2");
                        }));

                        stoppUhrSekunden.startUhr();
                        Thread.Sleep(1000);

                        if (stoppUhrSekunden.gibZahl() == 0)
                        {
                            stoppUhrMinuten.startUhr();
                            if (stoppUhrMinuten.gibZahl() == 0)
                            {
                                stoppUhrStunden.startUhr();
                            }
                        }

                    }
                });
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            stoppUhrAn = false;
            stoppUhrAnzeige.Text = "00:00:00";
        }
    }
}
